﻿using System;
using System.Collections.Generic;

namespace Program
{
    class Tienda
    {
        static double totalCompra = 0; // Variable global para acumular el total de la compra

        public static void Main(string[] args)
        {
            List<Dictionary<string, object>> productos = new List<Dictionary<string, object>>();
            productos.Add(new Dictionary<string, object> { { "Nombre", "Gomitas" }, { "Precio", 200 }, { "Cantidad", 100 }});
            productos.Add(new Dictionary<string, object> { { "Nombre", "Alfajor" }, { "Precio", 2500 }, { "Cantidad", 25 }});
            productos.Add(new Dictionary<string, object> { { "Nombre", "Platanos" }, { "Precio", 2800 }, { "Cantidad", 0 }});
            productos.Add(new Dictionary<string, object> { { "Nombre", "Papas" }, { "Precio", 2000 }, { "Cantidad", 50 }});

            Console.WriteLine("Bienvenidos a la tienda de Ana");
            ShowMenu(productos);
        }

        // Mostrar Menu
        public static void ShowMenu(List<Dictionary<string, object>> list)
        {
            Console.WriteLine("    --- Menú ---\n¿ Que deseas Comprar ?\n");
            Console.WriteLine($"{"NOMBRE",-20}{"PRECIO",9}{"CANTIDAD",10}");
            foreach (var producto in list)
            {
                Console.Write($"{producto["Nombre"],-20}{producto["Precio"],9:F2}{producto["Cantidad"],10}");
                Console.WriteLine();
            }
            string nombre = Console.ReadLine().ToLower();
            findProduct(nombre, list);
        }

        // Buscar producto
        public static void findProduct(string nombre, List<Dictionary<string, object>> list)
        {
            bool encontrado = false;
            foreach (var product in list)
            {
                if (product["Nombre"].ToString().ToLower() == nombre)
                {
                    Console.WriteLine("¿ Cuantos productos deseas Comprar ?");
                    int cantidad = int.Parse(Console.ReadLine());
                    validQuantity(cantidad, product, list);
                    encontrado = true;
                }
            }

            if (!encontrado)
            {
                Console.WriteLine("Producto no encontrado");
                wantsBuy(list);
            }
        }

        // Validar cantidad del producto
        public static void validQuantity(int cantidad, Dictionary<string, object> producto, List<Dictionary<string, object>> listProduct)
        {
            int stock = Convert.ToInt32(producto["Cantidad"]);
            if (cantidad <= stock)
            {
                producto["Cantidad"] = stock - cantidad;
                calculateTotal(producto, cantidad);
                if (!wantsBuy(listProduct))
                {
                    printInvoice(listProduct);
                }
            }
            else
            {
                Console.WriteLine($"La cantidad sobrepasa nuestro stock: {stock}, Recuerda que puedes visualizar nuestro stock en el menú");
                wantsBuy(listProduct);
            }
        }

        // Validar si el cliente quiere seguir comprando
        public static bool wantsBuy(List<Dictionary<string, object>> listProducto)
        {
            Console.WriteLine(" ¿ Quieres seguir comprando ? s/n");
            string continuar = Console.ReadLine().ToLower();
            if (continuar == "s")
            {
                ShowMenu(listProducto);
                return true;
            }
            else
            {
                Console.WriteLine("Gracias por tu compra.\n");
                return false;
            }
        }

        // Calcular el total de la orden
        public static void calculateTotal(Dictionary<string, object> producto, int cantidad)
        {
            if (double.TryParse(producto["Precio"].ToString(), out double precio))
            {
                double subtotal = precio * cantidad;
                totalCompra += subtotal; // Acumulamos en el total de la compra
            }
        }

        // Imprimir la factura
        public static void printInvoice(List<Dictionary<string, object>> listProducto)
        {
            Console.WriteLine("--------- FACTURA ---------");
            Console.WriteLine($"Total sin descuento: {totalCompra:C2}");

            double descuento = 0;
            if (totalCompra > 20000)
            {
                descuento = totalCompra * 0.20;
            }
            else if (totalCompra > 10000 && totalCompra <= 20000)
            {
                descuento = totalCompra * 0.10;
            }

            double totalFinal = totalCompra - descuento;

            Console.WriteLine($"Descuento aplicado: {descuento:C2}");
            Console.WriteLine($"Total a pagar: {totalFinal:C2}");
            Console.WriteLine("----------------------------");
        }
    }
}
